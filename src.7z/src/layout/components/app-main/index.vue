<template>
    <transition name="fade-transform" mode="out-in">
        <router-view />
    </transition>
</template>

<script>
export default {
    name: 'AppMain'
}
</script>